Snake Sprites
-------------

2D sprite graphics tiles for the classic snake game,
includes snake head, snake blobs, apple, wall blocks, bomb, easter egg, oliebol.
Originally used in Impossible Snake (html5/web, 2017)

You may use these graphics in personal and commercial projects.
Credit would be appreciated but is not mandatory.

Graphics by Bas de Reuver (www.bdrgames.nl, bdr1976@gmail.com)